


//
//  PPShareView.m
//  PPShareView
//
//  Created by macfai on 16/3/3.
//  Copyright © 2016年 pengpeng. All rights reserved.
//

#import "PPShareView.h"

#define kSCREENWIDTH     [UIScreen mainScreen].bounds.size.width
#define kSCREENHEIGHT    [UIScreen mainScreen].bounds.size.height

@interface PPShareView()

@property(nonatomic,strong)UIView *bottomShareView;

@end

@implementation PPShareView

-(instancetype)initWithTitles:(NSArray *)titleArray images:(NSArray *)imagesArray{
    
    self = [super init];
    if (self) {
        
        self.frame = [UIScreen mainScreen].bounds;
        self.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.3];
        if (kSCREENWIDTH>320) {
            self.bottomShareView = [[UIView alloc]initWithFrame:CGRectMake(0, kSCREENHEIGHT, kSCREENWIDTH, 280)];
        }else{
            self.bottomShareView = [[UIView alloc]initWithFrame:CGRectMake(0, kSCREENHEIGHT, kSCREENWIDTH, 240)];
        }
        
        self.bottomShareView.backgroundColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1.0];
        
        [self addSubview:self.bottomShareView];
        
        
        for (int j=0; j<2; j++) {
            
            for (int i=0; i<4; i++) {
                
                UIButton* btn = [UIButton buttonWithType:UIButtonTypeCustom];
                
                btn.tag = 100+i+j*4;
                
                btn.frame = CGRectMake(20*(i+1)+(kSCREENWIDTH-100)/4*i, 20*(j+1)+(kSCREENWIDTH-100)/4*j, (kSCREENWIDTH-100)/4, (kSCREENWIDTH-100)/4);
                
                
                [btn setBackgroundImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:imagesArray[i+4*j] ofType:@"png"]] forState:UIControlStateNormal];
                
                [btn addTarget:self action:@selector(shareBtnPress:) forControlEvents:UIControlEventTouchUpInside];
                
                [_bottomShareView addSubview:btn];
                
                UILabel* label = [[UILabel alloc] init];
                
                label.frame = CGRectMake(20*(i+1)+(kSCREENWIDTH-100)/4*i, 20*(j+1)+(kSCREENWIDTH-100)/4*(j+1), (kSCREENWIDTH-100)/4, 20);
                
                label.font = [UIFont systemFontOfSize:13];
                label.text = titleArray[i+4*j];
                label.textAlignment = NSTextAlignmentCenter;
                label.textColor = [UIColor blackColor];
                [_bottomShareView addSubview:label];
            }
            
        }
        
        UIButton* cancleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        cancleBtn.frame = CGRectMake(8, _bottomShareView.frame.size.height-60, kSCREENWIDTH-16, 44);
        cancleBtn.layer.borderColor = [UIColor redColor].CGColor;
        cancleBtn.layer.borderWidth = .5;
        [cancleBtn setTitle:@"取消" forState:UIControlStateNormal];
        [cancleBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [cancleBtn addTarget:self action:@selector(canclebtnPress) forControlEvents:UIControlEventTouchUpInside];
        [_bottomShareView addSubview:cancleBtn];
        
        [self addSubview:_bottomShareView];
    }
    
    return self;
}

-(void)currentSelectedIndex:(PPBlock)block{
    self.block = block;
}

-(void)shareBtnPress:(UIButton *)btn{
    self.block(btn.tag);
    [self dismiss];
}

-(void)canclebtnPress{
    [self dismiss];
}

-(void)show{
    
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    [UIView animateWithDuration:.3 animations:^{
        if (kSCREENWIDTH>320) {
            _bottomShareView.transform = CGAffineTransformMakeTranslation(0,  - 280);
        }else{
            _bottomShareView.transform=  CGAffineTransformMakeTranslation(0, -240);
        }
        
    }];
}

-(void)dismiss{
    
    [UIView animateWithDuration:0.3 animations:^{
        
        _bottomShareView.transform = CGAffineTransformIdentity;
        
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    [super touchesBegan:touches withEvent:event];
    [self dismiss];
}



@end
