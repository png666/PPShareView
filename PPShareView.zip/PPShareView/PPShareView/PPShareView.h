//
//  PPShareView.h
//  PPShareView
//
//  Created by macfai on 16/3/3.
//  Copyright © 2016年 pengpeng. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^PPBlock) (NSUInteger index);

@interface PPShareView : UIView

@property(nonatomic,copy)PPBlock block;

-(instancetype)initWithTitles:(NSArray *)titleArray images:(NSArray *)imagesArray;

-(void)show;

-(void)currentSelectedIndex:(PPBlock)block;



@end
