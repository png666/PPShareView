//
//  ViewController.m
//  PPShareView
//
//  Created by macfai on 16/3/3.
//  Copyright © 2016年 pengpeng. All rights reserved.
//

#import "ViewController.h"
#import "PPShareView.h"
@interface ViewController ()

@property(nonatomic,strong)PPShareView *shareView;

@end

@implementation ViewController


- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (IBAction)shareAction:(id)sender {

    NSArray* imageArr = @[@"2.1.0小区信息_0311",@"2.1.0小区信息－分享_05",@"2.1.0小区信息－分享_07",@"2.1.0小区信息－分享_17",@"2.1.0小区信息－分享_15",@"2.1.0小区信息－分享_16",@"2.1.0小区信息－分享_09",@"2.1.0小区信息－分享_18"];
    NSArray* titleArr = @[@"微信",@"朋友圈",@"QQ",@"短信",@"腾讯微博",@"新浪微博",@"QQ空间",@"人人网"];
    _shareView = [[PPShareView alloc]initWithTitles:titleArr images:imageArr];
    [_shareView show];
    [_shareView currentSelectedIndex:^(NSUInteger index) {
        NSLog(@"%ld",index);
    }];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
